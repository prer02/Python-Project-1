#!/usr/bin/env python
# coding: utf-8

# # PROJECT (by Prerna Gautam)

# In[60]:


#1. What is the average median income of the data set and check the distribution of data using appropriate plots. 
#Please explain the distribution of the plot.
import pandas as pd
datasets=pd.read_excel(r"C:\Users\lenovo\Downloads\housing+(1).xlsx") #loaded the dataset 
print(datasets.head(5))    #displayed the dataset
avg_median=datasets["median_income"].median() #calculated the median 
print(round(avg_median,2))


# In[ ]:





# In[72]:


#2. Draw an appropriate plot to see the distribution of housing_median_age and explain your observations.

plt.hist(datasets["median_income"],color='m')
plt.grid("true")
plt.xlabel("count")
plt.ylabel("Median_Income")
plt.title("Distribution of Median_Income",color='brown',size=20)
plt.show()
#This shows that the data is right skewed 


# In[61]:


plt.figure(figsize=(10, 5))
plt.hist(datasets["housing_median_age"], bins=10, edgecolor='k')
plt.xlabel("Housing Median Age")
plt.ylabel("Frequency")
plt.title("Distribution of Housing Median Age")
plt.show()


# In[89]:


#3. Show with the help of visualization, how median_income and median_house_values are related?
datas=datasets.head(1000)    

import matplotlib.pyplot as plt

# Assuming you have a DataFrame named 'df' containing the data
df = datas # Replace 'your_dataframe' with the actual DataFrame containing the data

# Create a scatter plot
plt.figure(figsize=(8, 6))
plt.scatter(df['median_income'], df['median_house_value'], alpha=0.5,marker='p',edgecolor='blue',facecolor='red')
plt.title('Relationship between Median Income and Median House Value',
         fontname='Arial',fontsize=14, fontweight='bold', style='italic')
plt.xlabel('Median Income',fontname="Brush Script MT", fontsize=25)
plt.ylabel('Median House Value',fontname="Brush Script MT", fontsize=25)

# Show the plot
plt.show()




   

   
   
   
   


# In[95]:


#4 Create a data set by deleting the corresponding examples from the data set for which total_bedrooms are not available.
import pandas as pd
new_df=datasets.dropna(subset=["total_bedrooms"]) #dropna will help in deleting the desired dataset 
new_df


# In[91]:


import pandas as pd
new_df=datasets.dropna(subset=["total_bedrooms"])


# In[81]:


import pandas as pd


# Create a new dataset with rows where 'total_bedrooms' are available
new_df = datasets.dropna(subset=["total_bedrooms"])

# Save the new dataset to a new Excel file if needed
new_df.to_excel("new_housing_dataset.xlsx", index=False)

# Display the first few rows of the new dataset
new_df.head(50)


# In[96]:


#5 Create a data set by filling the missing data with the mean value of the total_bedrooms in the original data set.

x=datasets["total_bedrooms"].mean()
# Fill missing values with the mean
datasets['total_bedrooms'].fillna(x, inplace=True)

# Save the new dataset to a new Excel file if needed
datasets.to_excel("new_housing_dataset_filled.xlsx", index=False)

# Display the first few rows of the new dataset
datasets.head(10)


# In[103]:


# 6 Write a programming construct (create a user defined function) to calculate the median value of the data set wherever
#required.
import pandas as pd
import numpy as np
def median_value(x):
       aa=np.median(x)
       return aa
     

median_value([1,2,3,4,5,6,7,8,9])
        
def median_v(data):  
#sort data for calculating median    
    sorted_data=sorted(data)    
    x=len(data)
#Logic to calculate median     
    if x%2==0:                              
        s=x//2
        t=(x//2)-1
        aa=(sorted_data[s]+sorted_data[t])/2
    else:
        s=(x+1)//2
        aa=sorted_data[s]
#returned the value of aa as the result
        
    return aa                                  
median_v([1,2,3,45,6,72,8,9])
            
     







# In[107]:


# 7 Plot latitude versus longitude and explain your observations.

import matplotlib.pyplot as plt
import seaborn as sns
datasets=pd.read_excel(r"C:\Users\lenovo\Downloads\housing+(1).xlsx")
#datasets.head(5)

sns.scatterplot(x="longitude", y="latitude", data=datasets, marker='p', edgecolor='purple', facecolor='black')
plt.title("THE RELATIONSHIP BETWEEN LATITUDE AND LONGITUDE",color="brown",fontname='Franklin Gothic Medium', fontsize=18)
plt.show()


# In[42]:


#8 Create a data set for which the ocean_proximity is ‘Near ocean’.
datasets[datasets["ocean_proximity"]=="NEAR OCEAN"]


# In[108]:


#9 Find the mean and median of the median income for the data set created in question 8.

datasets   
mean=datasets["median_income"].mean()  # Calculated the mean of the Median_income
median=datasets["median_income"].median()   #Calculated the median of the Median_income
print("The Mean of the median_income is",round(mean,2))
print("The Median of the median_income is",round(median,2))


# In[109]:


# 10 Please create a new column named total_bedroom_size. If the total bedrooms is 10 or less, it should be quoted as small. If the total bedrooms is 11 or more but less than 1000, 
#it should be medium, otherwise it should be considered large.

# Define a function to categorize 'total_bedrooms' size
def categorize_bedroom_size(total_bedrooms):
    if total_bedrooms <= 10:
        return 'small'
    elif 11 <= total_bedrooms < 1000:
        return 'medium'
    else:
        return 'large'

# Apply the function to create the 'total_bedroom_size' column
datasets['total_bedroom_size'] = datasets['total_bedrooms'].apply(categorize_bedroom_size)

# Display the updated DataFrame
datasets  





# In[ ]:




